package piscine

func Capitalize(s string) string {
	runes := []rune(s)
	capNext := true // first letter of a word should be capitalized

	for i := 0; i < len(runes); i++ {
		// Check if current rune is a letter
		if runes[i] >= 'a' && runes[i] <= 'z' {
			if capNext {
				runes[i] = runes[i] - ('a' - 'A') // capitalize
			}
			capNext = false
		} else if runes[i] >= 'A' && runes[i] <= 'Z' {
			if capNext {
				// already uppercase, ok
			} else {
				// uppercase inside a word → lowercase it
				runes[i] = runes[i] + ('a' - 'A')
			}
			capNext = false
		} else if runes[i] >= '0' && runes[i] <= '9' {
			// digits are part of words
			capNext = false
		} else {
			// non-alphanumeric character → next letter starts a new word
			capNext = true
		}
	}

	return string(runes)
}
