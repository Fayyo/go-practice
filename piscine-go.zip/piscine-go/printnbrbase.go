package piscine

import "github.com/01-edu/z01"

func PrintNbrBase(nbr int, base string) {
	if !isValidBase(base) {
		z01.PrintRune('N')
		z01.PrintRune('V')
		return
	}

	if nbr < 0 {
		z01.PrintRune('-')
		// Convert to uint to safely handle min int
		printNbrBaseRecursive(uint(-nbr), base, len(base))
	} else {
		printNbrBaseRecursive(uint(nbr), base, len(base))
	}
}

func printNbrBaseRecursive(nbr uint, base string, baseLen int) {
	if nbr >= uint(baseLen) {
		printNbrBaseRecursive(nbr/uint(baseLen), base, baseLen)
	}
	z01.PrintRune(rune(base[nbr%uint(baseLen)]))
}

func isValidBase(base string) bool {
	if len(base) < 2 {
		return false
	}
	used := make(map[rune]bool)
	for _, c := range base {
		if c == '+' || c == '-' || used[c] {
			return false
		}
		used[c] = true
	}
	return true
}
