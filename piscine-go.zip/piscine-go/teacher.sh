#!/bin/bash
KEY_INTERVIEW=$(
    grep -rl "L337" interviews/ |
    awk -F'-' 'NR==1 {print $2}'
)

echo "$KEY_INTERVIEW"
cat "interviews/interview-$KEY_INTERVIEW"
echo "$MAIN_SUSPECT"