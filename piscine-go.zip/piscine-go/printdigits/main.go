package main

import "github.com/01-edu/z01"

func main() {
	for a := 0; a < 10; a++ {
		z01.PrintRune(rune(a) + '0')
	}
	z01.PrintRune('\n')
}
