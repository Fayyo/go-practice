package piscine

func NRune(s string, n int) rune {
	r := []rune(s)
	if n <= len(s) && n > 0 {
		return r[n-1]
	} else {
		return 0
	}
}
