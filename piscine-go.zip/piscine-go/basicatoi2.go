package piscine

func BasicAtoi2(s string) int {
	if s == "" {
		return 0
	}
	n := 0
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c < '0' || c > '9' {
			return 0
		}
		d := int(c - '0')
		n = n*10 + d
	}
	return n
}
