package piscine

import "github.com/01-edu/z01"

func PrintCombN(n int) {
	if n <= 0 || n >= 10 {
		return
	}

	var digits [10]rune
	buildComb(0, '0', n, digits)
	z01.PrintRune('\n')
}

func buildComb(pos int, start rune, n int, digits [10]rune) {
	if pos == n {
		for i := 0; i < n; i++ {
			z01.PrintRune(digits[i])
		}

		if digits[0] != rune('0'+(10-n)) {
			z01.PrintRune(',')
			z01.PrintRune(' ')
		}
		return
	}

	for d := start; d <= '9'; d++ {

		if pos > 0 && d <= digits[pos-1] {
			continue
		}

		digits[pos] = d
		buildComb(pos+1, d+1, n, digits)
	}
}
