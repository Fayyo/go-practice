package main

import (
	"os"

	"github.com/01-edu/z01"
)

func isVowel(r rune) bool {
	switch r {
	case 'a', 'e', 'i', 'o', 'u',
		'A', 'E', 'I', 'O', 'U':
		return true
	}
	return false
}

func main() {
	args := os.Args[1:]
	if len(args) < 1 {
		z01.PrintRune('\n')
		return
	}

	var allRunes []rune
	for i, arg := range args {
		for _, r := range arg {
			allRunes = append(allRunes, r)
		}
		if i < len(args)-1 {
			allRunes = append(allRunes, ' ')
		}
	}

	var vowels []rune
	for _, r := range allRunes {
		if isVowel(r) {
			vowels = append(vowels, r)
		}
	}

	vowelIndex := len(vowels) - 1
	for i, r := range allRunes {
		if isVowel(r) {
			allRunes[i] = vowels[vowelIndex]
			vowelIndex--
		}
	}

	for _, r := range allRunes {
		z01.PrintRune(r)
	}
	z01.PrintRune('\n')
}
