package piscine

func UltimateDivMod(a *int, b *int) {
	j := *a
	k := *b

	*a = j / k
	*b = j % k
}
