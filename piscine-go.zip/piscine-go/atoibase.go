package piscine

func AtoiBase(s string, base string) int {
	if !isValidBasePrint(base) {
		return 0
	}
	sign, startIndex := parseSignAndStartIndex(s)
	result := 0
	baseLen := len(base)

	for i := startIndex; i < len(s); i++ {
		digitValue := indexInBase(s[i], base)
		if digitValue == -1 {
			break
		}
		result = result*baseLen + digitValue
	}
	return result * sign
}

func isValidBasePrint(base string) bool {
	if len(base) < 2 {
		return false
	}
	seen := make(map[rune]bool)
	for _, char := range base {
		if char == '+' || char == '-' || seen[char] {
			return false
		}
		seen[char] = true
	}
	return true
}

func parseSignAndStartIndex(s string) (int, int) {
	sign := 1
	startIndex := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '-' {
			sign *= -1
			startIndex++
		} else if s[i] == '+' {
			startIndex++
		} else {
			break
		}
	}
	return sign, startIndex
}

func indexInBase(char byte, base string) int {
	for i := 0; i < len(base); i++ {
		if base[i] == char {
			return i
		}
	}
	return -1
}
