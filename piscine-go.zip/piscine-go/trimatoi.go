package piscine

func TrimAtoi(s string) int {
	sign := 1
	numberStarted := false
	result := 0
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c == '-' && !numberStarted {
			sign = -1
			numberStarted = true
		} else if c >= '0' && c <= '9' {
			numberStarted = true
			result = result*10 + int(c-'0')
		} else if c == '+' && !numberStarted {
			numberStarted = true
		}
	}
	return result * sign
}
