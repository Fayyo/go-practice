package piscine

func Compare(a, b string) int {
	alen := len(a)
	blen := len(b)
	diff := 0
	if alen > blen {
		diff = blen
	} else {
		diff = alen
	}
	for i := 0; i < diff; i++ {
		if a > b {
			return 1
		} else if a < b {
			return -1
		}
	}
	return 0
}
