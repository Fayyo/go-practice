package piscine

func FindNextPrime(nb int) int {
	prime := nb
	if nb < 2 {
		return 2
	}
	for j := 2; j <= nb/2; j++ {
		prime = nb % j
		if prime == 0 {
			return FindNextPrime(nb + 1)
		}
	}
	return nb
}
