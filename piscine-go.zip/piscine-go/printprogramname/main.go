package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	name := os.Args

	final := name[0] // this is the program name

	final = final[2:]

	fRune := []rune(final) // this is to remove the "./" from the beginning

	for i := 0; i < len(fRune); i++ {
		z01.PrintRune(fRune[i])
	}
	z01.PrintRune('\n')
}
