package piscine

func PrintNbrInOrder(n int) {
	if n < 0 {
		n = -n
	}
	digits := []int{}
	if n == 0 {
		digits = append(digits, 0)
	}
	for n > 0 {
		digits = append(digits, n%10)
		n /= 10
	}
	for i, j := 0, len(digits)-1; i < j; i, j = i+1, j-1 {
		digits[i], digits[j] = digits[j], digits[i]
	}
	for i := 0; i < len(digits)-1; i++ {
		for j := i + 1; j < len(digits); j++ {
			if digits[i] > digits[j] {
				digits[i], digits[j] = digits[j], digits[i]
			}
		}
	}
	for _, digit := range digits {
		PrintNbr(digit)
	}
}
