package piscine

func FirstRune(s string) rune {
	r := []rune(s)
	first := r[0]

	return first
}
