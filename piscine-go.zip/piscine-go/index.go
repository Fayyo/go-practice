package piscine

func Index(s string, toFind string) int {
	if len(toFind) == 0 {
		return 0
	}

	runes := []rune(s)
	find := []rune(toFind)

	for i := 0; i <= len(runes)-len(find); i++ {
		match := true
		for j := 0; j < len(find); j++ {
			if runes[i+j] != find[j] {
				match = false
				break
			}
		}
		if match {
			return i
		}
	}
	return -1
}
