package piscine

func Swap(a *int, b *int) {
	j := *a
	k := *b

	*a = k
	*b = j
}
