package piscine

func LastRune(s string) rune {
	r := []rune(s)
	n := len(r) - 1
	lr := r[n]
	return lr
}
