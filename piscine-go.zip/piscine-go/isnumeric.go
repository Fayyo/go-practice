package piscine

func IsNumeric(s string) bool {
	for _, c := range s {
		if !(c >= '0' && c <= '9') {
			return false
		}
	}
	return true
}
