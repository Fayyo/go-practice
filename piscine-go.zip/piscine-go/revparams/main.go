package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	name := os.Args

	for i := len(name) - 1; i > 0; i-- {
		for j := 0; j < len(name[i]); j++ {
			z01.PrintRune(rune(name[i][j]))
		}
		z01.PrintRune('\n')
	}
}
