package main

import (
	// "fmt"
	"github.com/01-edu/z01"
	// "piscine"
)

func CheckNumber(arg string) bool {
	for _, s := range arg {
		if s <= '9' {
			return true
		}
	}
	return false
}

func CountAlpha(s string) int {
	t := 0
	for _, c := range s {
		if c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' {
			t++
		}
	}
	return t
}

func CountChar(str string, c rune) int {
	t := 0
	if len(str) == 0 {
		return 0
	}
	for _, s := range str {
		if s == c {
			t++
		}
	}
	return t
}

func PrintIf(str string) string {
	if len(str) == 0 {
		return "G\n"
	}
	if len(str) >= 3 {
		return "G\n"
	} else {
		return "Invalid Input\n"
	}

}

func PrintIfNot(str string) string {
	if len(str) < 3 {
		return "G\n"
	} else {
		return "Invalid Input\n"
	}
}

func RetainFirstHalf(str string) string {
	i := 0
	half := []rune(str)
	hl := len(str) / 2
	result := ""
	if len(str) == 0 {
		return ""
	} else if len(str) == 1 {
		return str
	}

	for i <= hl {
		result = string(half[:i])
		i++
	}
	return result
}

func CamelToSnakeCase(s string) string {
	n := len(s)
	if s == "" {
		return ""
	} else if s[n-1] >= 'A' && s[n-1] <= 'Z' {
		return s
	}
	result := ""
	for _, i := range s {
		if (s[i] >= 'A' && s[i] <= 'Z') && (s[i+1] >= 'A' && s[i+1] <= 'Z') {
			return s
		} else if (s[i] >= 'A' && s[i] <= 'Z') && i > 0 {
			result += "_"
		}
		result += string(s[i])

	}
	return result
}

func DigitLen(n, base int) int {
	if base < 2 || base > 36 {
		return -1
	}
	if n < 0 {
		n = -n
	}
	count := 0
	for n > 0 {
		n = n / base
		count++
	}
	return count
}

func FirstWord(s string) string {
	word := ""

	for _, c := range s {
		if c == ' ' {
			break
		}
		word += string(c)
	}
	word += "\n"
	return word
}

func Gcd(a, b uint) uint {
	if a == 0 || b == 0 {
		return 0
	}
	for b != 0 {
		a, b = b, a%b
	}
	return a
}

func HashCode(dec string) string {
	n := len(dec)
	r := []rune(dec)
	code := ""

	for i := 0; i < n; i++ {
		h := (int(r[i]) + n) % 127

		if h < 0 || h > 127 {
			h += 33
		}
		code += string(rune(h))
	}
	return code
}

func LastWord(s string) string {
	n := len(s)
	end := n - 1
	r := []rune(s)

	if end > 0 && r[end] == ' ' {
		end--
	}
	start := end

	for start > 0 && r[start] != ' ' {
		start--
	}
	return string(r[start+1:end+1]) + "\n"
}

func RepeatAlpha(s string) string {
	out := ""
	for _, c := range s {
		if c >= 'A' && c <= 'Z' {
			times := int(c - 'A' + 1)
			for i := 0; i < times; i++ {
				out += string(c)
			}
		} else if c >= 'a' && c <= 'z' {
			times := int(c - 'a' + 1)
			for i := 0; i < times; i++ {
				out += string(c)
			}
		} else {
			out += string(c)
		}
	}
	return out
}

func FindPrevPrime(nb int) int {
	if nb < 2 {
		return 0
	}

	for i := nb; i >= 2; i-- {
		prime := true

		for j := 2; j*j <= i; j++ {
			if i%j == 0 {
				prime = false
				break
			}
		}
		if prime {
			return i
		}
	}
	return 0
}

func FromTo(from int, to int) string {
	if (from < 0 || from > 99) || (to < 0 || to > 99) {
		return "Invalid \n"
	}
	out := ""

	if from <= to {
		for i := from; i <= to; i++ {
			if i < 10 {
				out += "0" + string('0'+i)
			} else {
				out += string('0'+i/10) + string('0'+i%10)
			}

			if i < to {
				out += ", "
			}
		}

	} else {
		for i := from; i >= to; i-- {
			if i < 10 {
				out += "0" + string('0'+i)
			} else {
				out += string('0'+i/10) + string('0'+i%10)
			}
			if i > to {
				out += ", "
			}
		}
	}
	return out + "\n"
}

func IsCapitalized(s string) bool {
	if len(s) <= 0 {
		return false
	}

	if s[0] >= 'a' && s[0] <= 'z' {
		return false
	}

	for i := 0; i < len(s); i++ {
		ch := s[i]

		if ch == ' ' && i+1 < len(s) {
			next := s[i+1]
			if next >= 'a' && next <= 'z' {
				return false
			}
		}
	}
	return true
}

func Itoa(n int) string {
	if n == 0 {
		return "0"
	}
	sign := ""

	if n < 0 {
		sign = "-"
		n = -n
	}
	result := ""
	for n > 0 {
		nb := rune('0' + n%10)
		ch := string(nb)
		result = ch + result
		n /= 10
	}
	return sign + result
}

func revcomb() {
	for i := '9'; i >= '2'; i-- {
		for j := '8'; j >= '1'; j-- {
			for k := '7'; k >= '0'; k-- {
				if i > j && j > k {
					if i == '2' && j == '1' && k == '0' {
						z01.PrintRune(i)
						z01.PrintRune(j)
						z01.PrintRune(k)
					} else {
						z01.PrintRune(i)
						z01.PrintRune(j)
						z01.PrintRune(k)
						z01.PrintRune(',')
						z01.PrintRune(' ')
					}
				}

			}
		}
	}
	z01.PrintRune('\n')
}

func ThirdTimeIsACharm(str string) string {
	if len(str) < 3 {
		return "\n"
	}
	result := ""

	for i := 2; i < len(str); i += 3 {
		result += string(str[i])
	}
	return result + "\n"
}

func WeAreUnique(str1 , str2 string) int {
	if str1 == "" && str2 == "" {
		return -1
	} 
	var A, B [128] bool
	count := 0

	for _, c := range str1{
		if c < 128 {
			A[c] = true
		}
	}

	for _, c := range str2 {
		if c < 128 {
			B[c] = true
		}
	}

	for i:= 0; i < 128; i++ {
		if A[i] != B[i] {
			count++
			}
		}
		return count
	}
	

func AddPrevPrime(nb int) int {
	if nb < 2 {
		return 0
	}
	total:= 0

	for i := nb; i >= 2; i-- {
		prime := true

		for j := 2; j*j <= i; j++ {
			if i%j == 0 {
				prime = false
				break
			}
		}
		if prime {
			total += i
		}
	}
	return total
}

func main() {
// 	fmt.Println(WeAreUnique("foo", "boo"))
// 	fmt.Println(WeAreUnique("", ""))
// 	fmt.Println(WeAreUnique("abc", "def"))

AddPrevPrime(7)


}

// func main() {
// 	piscine.PrintMemory([10]byte{'h', 'e', 'l', 'l', 'o', 16, 21, '*'})
// }
