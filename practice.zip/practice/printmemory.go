package piscine

import "fmt"

func PrintMemory(arr [10]byte) {
	for i := 0; i < len(arr); i++ {
		fmt.Printf("%02x ", arr[i])
	}
		fmt.Printf("\n")
}
